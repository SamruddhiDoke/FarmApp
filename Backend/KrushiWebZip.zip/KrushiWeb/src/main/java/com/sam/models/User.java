package com.sam.models;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
public class User 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
	@Size(min = 3, max = 10, message = "User Name must be between 3 to 10 characters")
	@Column(nullable = false)
	private String name;
	
	@Email(message = "Enter Valid email")
	@Column(nullable = false,unique = true)
	private String email;
	
	@Pattern(regexp="(^$|[0-9]{10})", message="Enter a valid phone number")
	@Column(nullable=false)
	private String phoneNo;
	
	@Column(nullable=false)
	private String location;
	
	@Column(nullable=false)
	private String language;
	
	@Size(min = 8, max = 8, message = "Password must be of 8 characters")
	@Column(nullable = false)
	private String password;
	
	@Transient
	@Size(min = 8, max = 8, message = "Password must be of 8 characters")
	private String confirm_password;
	
	@CreatedDate
	@Column(updatable = false)
	private Instant createdAt;
	
	@LastModifiedDate
	private Instant updatedAt;
	
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<OtpVerification> otps = new ArrayList<>();
	
    
}
