package com.sam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KrushiWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
